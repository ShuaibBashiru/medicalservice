<template>
    <div>
<div class="col-md-10 col-md-offset-2 mt-1 maindiv">

        <div class="container">
            <div class="row">
                <div class="col">
        <h2 class="text-center">Hello! User</h2>
<p class="text-center"> Welcome to Covid-19 analitics dashboard.</p>
                </div>
            </div>

        </div>
</div>
</div>
</template>


<script>

</script>
<style>

</style>
