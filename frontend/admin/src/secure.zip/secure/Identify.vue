<template>
<div>
<div class="container-fluid">
<div class="row d-flex justify-content-center">
    <div class="col-md-3 mt-2">
  <form action="" role="form">
  <div class="form-row">
<div class="form-group col text-center">
    <h2>Identify</h2>
<p>ID verification panel</p>
</div>
    <div class="form-group mt-4 col">
<div class="rounded bg-secondary" style="height:200px;"></div>

</div>

      <div class="form-group mt-3 col">
     <button type="submit" name="signin" class="btn btn-outline-secondary form-control">Capture</button>
    </div>
      <div class="form-group mt-3 col">
     <button type="submit" name="signin" class="btn btn-primary form-control">Verify</button>
    </div>

  </div>
</form>



    </div>

</div>

</div>
</div>
</template>

<script>
export default{

}
</script>


<style>
header a{
    text-decoration: none;
}

li{
    list-style: none;
}
.body_image{
    width:445px;
    height: 120px;
}
</style>