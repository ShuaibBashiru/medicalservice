<template>
    <div>
        <div class="container">
            <div class="row">
                <div class="col"></div>
            </div>

        </div>
</div>
</template>

<script>

</script>
<style>

</style>
